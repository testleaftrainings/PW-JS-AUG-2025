import test from '@playwright/test'
import { request } from 'http'

let accessToken:any
let instUrl:any
let tokenType:any
let Id:any

test("Generate Token",async({request})=>{

//endpoint,header,data

const token=await request.post("https://login.salesforce.com/services/oauth2/token",{

headers:{

    "Content-Type":"application/x-www-form-urlencoded",
    "Connection":"keep-alive"
},
form:{
 "grant_type":"password"   ,
 "client_id":"3MVG9dAEux2v1sLs_5LgrWbWWJbMYKRgBajBibwGyik0pC_tXNFGsk6aV8h1owvGj6hsaxRWhzGX5WP1O87h5",
 "client_secret":"EE7E666EF8204C869125AC8160C78B0F93277C544B84F8B89A0D59AD9FB3AD1C",
 "username":"manikandanleo4922@agentforce.com",
 "password":"India@1234"
}
})

const resbody= await token.json()
accessToken=resbody.access_token
instUrl=resbody.instance_url
tokenType=resbody.token_type

//console.log(`${accessToken} , ${tokenType} , ${instUrl}`)

})

test("create Lead",async({request})=>{

    const response= await request.post(`${instUrl}/services/data/v64.0/sobjects/Lead`,{
headers:{

    "Content-Type":"application/json",
    "Authorization":`${tokenType} ${accessToken}`
},
data:{
        "firstname":"dilip",
    "lastname":"kumar",
"company":"TestLeaf"
}
    })
    const res=await response.json()
    Id=res.id
    console.log(Id)
})

test("Modify Lead",async({request})=>{

    const response= await request.patch(`${instUrl}/services/data/v64.0/sobjects/Lead/${Id}`,{
headers:{

    "Content-Type":"application/json",
    "Authorization":`${tokenType} ${accessToken}`
},
data:{
        "firstname":"dilip",
    "lastname":"kumar",
"company":"Qeagle"
}
    })
    
})


test("Delete Lead",async({request})=>{

    const response= await request.delete(`${instUrl}/services/data/v64.0/sobjects/Lead/${Id}}`,{
headers:{

    "Content-Type":"application/json",
    "Authorization":`${tokenType} ${accessToken}`
},
    })
    
})